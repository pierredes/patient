package com.example.patient.repositories;

import com.example.patient.entities.VilleEntity;
import org.springframework.data.repository.CrudRepository;

public interface VilleRepository extends CrudRepository<VilleEntity, Integer> {
}
